# CodexMiniBar

<p align="right">
  <strong>English</strong> | <a href="README.zh-CN.md">简体中文</a>
</p>

> Proprietary software — Copyright © 2026 JesseFei87. All rights reserved.

A native Windows quota toolbar for Codex. Built with C# / WPF and the .NET Framework 4.8 included with Windows, it requires no Node.js, Python, separate sign-in, API key, or activation. Download it and start using MiniBar directly.

## Launch and controls

Double-click **启动CodexMiniBar.cmd**, or open **bin/CodexMiniBar.exe** directly. MiniBar starts collapsed and attaches to the top of the selected Codex or VS Code host window. Codex is selected by default on first run.

For a ready-to-run Windows package, download [`dist/CodexMiniBar-Windows-x64-v1.1.0.zip`](dist/CodexMiniBar-Windows-x64-v1.1.0.zip), extract it, and open **CodexMiniBar.exe**.

The current build starts directly without activation. The existing activation implementation is retained in the source for possible future use; its deployment notes remain in [`licensing/README.md`](licensing/README.md).

- The collapsed view shows the account plan, remaining five-hour quota, remaining weekly quota, reset-card count, and a prominent weekly-reset countdown. The countdown automatically uses the shortest suitable unit: days, hours, or minutes.
- Plus uses a champagne-gold gradient wordmark, while Pro uses an ice-blue diamond wordmark. Contrast is tuned separately for dark and light themes, and the highlight may extend beyond the MiniBar border.
- Prolite is displayed consistently as Pro with the diamond-blue identity. When the account has no five-hour quota, both the collapsed summary and expanded details hide that empty item; the remaining information recenters and shifts left automatically.
- Click the text or right chevron to expand. The expanded panel shows quota progress bars, quota reset times, the subscription expiry with minute-level remaining time, the nearest reset-card expiry, and the last update time. Click again or press Esc to collapse it.
- Right-click the tray icon to switch between “Attach to Codex” and “Attach to VS Code.” The selection is stored in `%LOCALAPPDATA%\CodexMiniBar\host.txt` and takes effect immediately. MiniBar hides when the selected host is closed or minimized and remains visible when you switch to another application.
- Use “Language / 语言” in the tray menu to switch between English and Simplified Chinese immediately. The collapsed bar, expanded panel, prompts, and menu update together. The selection is stored in `%LOCALAPPDATA%\CodexMiniBar\language.txt`.
- Use “Subscription expiry…” in the tray menu to enter the local expiry time shown on the account page in `yyyy-MM-dd HH:mm` format. The value is stored in `%LOCALAPPDATA%\CodexMiniBar\subscription-expiry.txt`. The expanded panel shows both the absolute time and the remaining days, hours, and minutes, updated once per minute.
- Drag the dot-grid handle on the left to move MiniBar horizontally along the current host's top bar. Codex and VS Code keep separate positions; the default VS Code position is to the right of the title-bar search box.
- MiniBar refreshes every 30 seconds by default. Use “Refresh interval…” in the tray menu to choose a value from 10 to 1800 seconds, stored in `%LOCALAPPDATA%\CodexMiniBar\refresh-seconds.txt`. Refresh immediately from the lower-right corner of the expanded panel or the tray menu.
- The tray uses a deep-blue electric diamond icon. Network failures show direct guidance such as “Codex offline · Check network” and progressively back off refreshes to a maximum of 30 minutes. The user-selected interval resumes automatically after connectivity returns.
- Use the tray menu to restore the current host's default position or exit. Starting the program again does not create duplicate MiniBar instances.
- MiniBar hides when the current host is minimized, closed, or moved to another virtual desktop, then reappears after a visible target window is found again. Switching Codex conversations or VS Code editor tabs does not affect the host window lifecycle.

## Data and themes

MiniBar calls the read-only `account/rateLimits/read` method through the local `codex.exe app-server`. Each refresh creates a short-lived connection and reads the current sign-in state. MiniBar does not read or store sign-in tokens, create conversations, or consume reset cards. Failed reads display “—” instead of treating missing values as zero. Server-side quota data can arrive with a delay and is not streamed per token.

MiniBar prefers `rateLimitsByLimitId.codex` and uses `windowDurationMins` to identify the five-hour and weekly windows. Remaining quota is calculated as `100 - usedPercent`. Reset cards come from `rateLimitResetCredits.availableCount` and are separate from paid credit balances.

The current Codex app-server `account/read` and `account/rateLimits/read` protocols do not expose subscription expiry or renewal dates; their `expiresAt` field belongs only to quota reset cards. To avoid misleading estimates, users enter the subscription expiry shown on their account page. MiniBar does not infer subscription dates from quota reset times.

Every second, MiniBar checks `desktop.appearanceTheme` and the matching `appearanceLightChromeTheme` / `appearanceDarkChromeTheme` values in `config.toml` under the active `CODEX_HOME` (default `%USERPROFILE%\.codex`). It follows light and dark modes plus custom `surface`, `ink`, and `accent` colors. When the theme is set to system, it follows the Windows app theme.

MiniBar is a Win32-owned tool window and does not modify the Codex or VS Code installation. It recognizes legacy `Codex.exe`, the current native `OpenAI.Codex_*\app\ChatGPT.exe`, and the official VS Code `Microsoft VS Code\Code.exe` main window while excluding CLI processes, unrelated processes with similar names, and small notification windows. It follows the target window's movement, DPI, and native stacking order without using global always-on-top. The attachment is visual; MiniBar does not register an extension inside the host.

## Build and validation

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
Start-Process .\bin\CodexMiniBar.exe -ArgumentList '--self-test --output artifacts\test-results.txt' -Wait
Start-Process .\bin\CodexMiniBar.exe -ArgumentList '--probe --output artifacts\probe.json' -Wait
Start-Process .\bin\CodexMiniBar.exe -ArgumentList '--inspect --output artifacts\windows.json' -Wait
Start-Process .\bin\CodexMiniBar.exe -ArgumentList '--render-preview --output artifacts\previews' -Wait
Start-Process .\bin\CodexMiniBar.exe -ArgumentList '--render-activation --output artifacts\activation.png' -Wait
```

Create the `artifacts` directory before running these checks manually for the first time. Diagnostics must run as the signed-in Windows user because a sandbox account does not share that user's Codex sign-in state. `--probe` exports only quota, theme, and window geometry; it does not export email addresses, account IDs, or tokens. `--preview` opens a separate interactive window clearly marked as sample data for UI validation only.

See [`VALIDATION.md`](VALIDATION.md) for verified behavior. The application is adapted to the Codex version currently installed on the development machine. Future changes to Codex process layout, theme format, or app-server protocols may require corresponding updates.

## macOS Apple Silicon

The macOS edition is a native menu-bar app with quota reads, reset cards, automatic refresh, network backoff, subscription expiry, and live English/Chinese switching. It starts directly without activation. It does not reproduce the Windows title-bar attachment because macOS uses a different window model.

Install from `dist/CodexMiniBar-macOS-Apple-Silicon.dmg`: open the DMG and drag CodexMiniBar to Applications. The automated build currently uses an ad-hoc signature; if Gatekeeper blocks the first launch, right-click the app in Finder and choose Open. Public distribution requires an Apple Developer ID signature and notarization.

The app requires an Apple Silicon Mac running macOS 13 or later. GitHub Actions builds the package on macOS and runs parser self-tests, arm64 architecture validation, code-signature verification, and DMG integrity verification.

## License

This repository and its source code are proprietary software for use only by the repository owner and explicitly authorized collaborators. Copying, modifying, publishing, distributing, selling, or reselling without written permission is prohibited. See [`LICENSE`](LICENSE) for the full terms.
