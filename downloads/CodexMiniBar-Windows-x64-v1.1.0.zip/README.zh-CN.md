# CodexMiniBar

<p align="right">
  <a href="README.md">English</a> | <strong>简体中文</strong>
</p>

> Proprietary software — Copyright © 2026 JesseFei87. All rights reserved.

Windows 原生 Codex 额度工具栏。使用 C# / WPF 和系统自带的 .NET Framework 4.8，无需 Node.js、Python、额外登录、API Key 或激活，下载后即可直接使用。

## 启动与操作

双击 **启动CodexMiniBar.cmd**，或直接打开 **bin/CodexMiniBar.exe**。默认折叠，运行后附着在已选择的 Codex 或 VS Code 主窗口顶部；首次运行默认选择 Codex。

需要开箱即用的 Windows 安装包时，下载并解压 [`dist/CodexMiniBar-Windows-x64-v1.1.0.zip`](dist/CodexMiniBar-Windows-x64-v1.1.0.zip)，然后打开 **CodexMiniBar.exe**。

当前版本首次启动时直接进入 MiniBar，无需激活。原有激活实现仍保留在源码中，供以后需要时恢复；部署说明仍见 [`licensing/README.md`](licensing/README.md)。

- 折叠态：显示账户等级、5 小时剩余额度、周剩余额度、重置卡数量，以及醒目的周额度重置倒计时；倒计时自动使用天、小时或分钟的最短单位。
- Plus 使用香槟金渐变艺术字，Pro 使用冰蓝钻石艺术字；深浅主题分别优化对比度，并保留越过 MiniBar 边框的高光外沿。
- Prolite 在界面中统一使用钻石蓝 Pro 标识；账户没有 5 小时额度时，折叠摘要和展开详情都隐藏该空项目，其余信息自动居中并向左补位。
- 点击文字或右侧箭头展开；展开后显示进度条、额度重置时间、订阅到期时间及分钟级剩余时长、重置卡最近到期时间和更新时间。再次点击或按 Esc 收起。
- 托盘右键可在“吸附到 Codex”和“吸附到 VS Code”之间切换，选择保存在 `%LOCALAPPDATA%\CodexMiniBar\host.txt`。切换后立即跟随目标窗口；目标未打开或最小化时隐藏，切换到其他应用时仍保持显示。
- 托盘菜单“语言 / Language”可在简体中文与 English 间实时切换；折叠条、展开面板、提示和菜单会同步更新，选择保存在 `%LOCALAPPDATA%\CodexMiniBar\language.txt`。
- 托盘菜单“订阅到期时间…”可按 `yyyy-MM-dd HH:mm` 填写账户页面显示的本地到期时间，保存到 `%LOCALAPPDATA%\CodexMiniBar\subscription-expiry.txt`。展开面板同时显示绝对时间与剩余天、小时、分钟，并每分钟更新。
- 拖动左侧点阵手柄可沿当前宿主的顶部栏横向移动。Codex 与 VS Code 分别保存位置；VS Code 的默认位置位于标题栏搜索框右侧。
- 默认每 30 秒自动刷新；系统托盘右键选择“刷新频率…”可在 10–1800 秒之间修改，设置会保存到 `%LOCALAPPDATA%\CodexMiniBar\refresh-seconds.txt`。展开面板右下角或托盘菜单可立即刷新。
- 托盘使用深蓝电光菱形图标。网络异常时显示“Codex 暂时连不上，请检查网络”等直白提示，并将刷新间隔逐级放慢至 30 分钟；连接恢复后自动回到用户设置的频率。
- 系统托盘菜单可恢复当前宿主的默认位置或退出。重复启动不会产生多个 MiniBar。
- 当前宿主最小化、关闭或切到其他虚拟桌面时隐藏；重新发现可见的目标主窗口后恢复。Codex 切换会话和 VS Code 切换编辑器标签都不参与窗口生命周期。

## 数据与主题

通过本机 Codex 自带的 `codex.exe app-server`，执行只读的 `account/rateLimits/read`。每次刷新创建一个短暂连接，读取当前登录状态；MiniBar 不读取或保存登录令牌，不创建对话，不消耗重置卡。读取失败时显示“—”，不会将缺失数据解释为零。后台数据可能存在服务端更新延迟，并非逐 token 推送。

优先读取 `rateLimitsByLimitId.codex`，根据 `windowDurationMins` 识别 5 小时和周窗口。额度显示为 `100 - usedPercent`；重置卡读取 `rateLimitResetCredits.availableCount`，与付费 credits 余额不同。

当前 Codex app-server 的 `account/read` 和 `account/rateLimits/read` 协议不提供订阅到期或续费日期；其中 `expiresAt` 仅属于额度重置卡。为避免误导，订阅到期时间由用户按账户页面设置，MiniBar 不用额度重置时间推算订阅日期。

每秒检查当前 `CODEX_HOME`（默认 `%USERPROFILE%\.codex`）下 `config.toml` 的 `desktop.appearanceTheme` 和对应的 `appearanceLightChromeTheme` / `appearanceDarkChromeTheme`。跟随明暗模式以及自定义的 `surface`、`ink`、`accent`；设置为 system 时跟随 Windows 应用主题。

采用 Win32 附属工具窗口，不修改 Codex 或 VS Code 安装文件。识别传统 `Codex.exe`、本机新版 `OpenAI.Codex_*\app\ChatGPT.exe` 和正式版 VS Code 的 `Microsoft VS Code\Code.exe` 主窗口，排除 CLI、无关同名程序和小提示窗。跟随目标窗口移动、DPI 和原生层叠顺序，不设全局置顶。属于视觉吸附，未向宿主内部注册扩展。

## 构建与验证

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
Start-Process .\bin\CodexMiniBar.exe -ArgumentList '--self-test --output artifacts\test-results.txt' -Wait
Start-Process .\bin\CodexMiniBar.exe -ArgumentList '--probe --output artifacts\probe.json' -Wait
Start-Process .\bin\CodexMiniBar.exe -ArgumentList '--inspect --output artifacts\windows.json' -Wait
Start-Process .\bin\CodexMiniBar.exe -ArgumentList '--render-preview --output artifacts\previews' -Wait
Start-Process .\bin\CodexMiniBar.exe -ArgumentList '--render-activation --output artifacts\activation.png' -Wait
```

首次手动运行这些检查前，先创建 `artifacts` 目录。诊断必须以实际登录 Windows 的账户运行，沙箱账户没有该用户的 Codex 登录状态。`--probe` 仅导出额度、主题和窗口几何信息，不导出邮箱、账户 ID 或令牌。`--preview` 打开明确标注示例数据的独立交互窗口，仅用于 UI 验证。

已验证项目见 `VALIDATION.md`。程序针对当前本机版本完成接口适配；Codex 后续更改进程布局、主题格式或 app-server 协议时，可能需要同步适配。

## macOS Apple Silicon

macOS 版本是原生菜单栏应用，支持额度读取、重置卡、自动刷新、网络退避、订阅到期时间和中英文切换，启动时无需激活。由于 macOS 的窗口机制不同，不提供 Windows 版的 Codex / VS Code 标题栏吸附。

从 `dist/CodexMiniBar-macOS-Apple-Silicon.dmg` 安装：打开 DMG，将 CodexMiniBar 拖入 Applications。当前自动构建包采用 ad-hoc 签名；首次运行如被 Gatekeeper 拦截，请在 Finder 中右键应用并选择“打开”。正式公开分发前需使用 Apple Developer ID 签名并完成公证。

需要在 macOS 13 或更高版本的 Apple Silicon Mac 上使用。安装包由 GitHub Actions 在 macOS 环境中执行解析自测、arm64 架构检查、签名检查和 DMG 完整性检查后生成。

## 许可

本仓库及其源码为专有软件，仅供仓库所有者和明确授权的协作者使用。未经书面许可，不得复制、修改、公开、分发、销售或转售。具体条款见 [`LICENSE`](LICENSE)。
